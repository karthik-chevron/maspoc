package ibmts.csc.util;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

import psdi.app.company.CompanySetRemote;
import psdi.app.financial.TaxSetRemote;
import psdi.app.item.CommoditySetRemote;
import psdi.app.item.ItemSetRemote;
import psdi.app.person.*;
import psdi.app.site.AddressSetRemote;
import psdi.app.site.OrganizationSetRemote;
import psdi.app.site.SiteSetRemote;
import psdi.app.labor.*;
import psdi.app.po.*;
import psdi.iface.mic.MicConstants;
import psdi.iface.mos.ConversionUtil;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.app.rfq.*;
import psdi.mbo.*;


public class CSCShipServUtilities {

	protected static final MXLogger integrationLogger = MXLoggerFactory
			.getLogger(MicConstants.INTEGRATION_LOGGER);

	/**
	 * Constructor
	 */
	public CSCShipServUtilities() {
	}

	/**
	 * Format MAXIMO date to SAP format
	 * 
	 * @param maxDate
	 *            maximo date
	 * @return MAXIMO date in SAP format
	 * @exception MXException
	 *                MAXIMO exception
	 * @exception RemoteException
	 *                Remote exception
	 */
	public static String dateToSAP(String maxDate) throws MXException,
			RemoteException 
	{
		if (integrationLogger.isDebugEnabled()) 
			{ integrationLogger.debug("ERPOutExt:dateToSAP");}

		String sapDate = null;
		try {
			Date date;
			if (isNull(maxDate)) {
				date = new java.util.Date();
			} else {
				date = ConversionUtil.stringToDate(maxDate);
			}

			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			sapDate = sdf.format(date);
		} catch (Exception e) {
			throw new MXApplicationException("iface", "sap_invalidDate");
		}

		return sapDate;
	}

	/**
	 * Format SAP date to MAXIMO format
	 * 
	 * @param sapDate
	 *            sap date
	 * @return SAP date in MAXIMO format
	 * @exception MXException
	 *                MAXIMO exception
	 * @exception RemoteException
	 *                Remote exception
	 */
	public static Date dateToMaximo(String sapDate) throws MXException,
			RemoteException 
	{
		if (integrationLogger.isDebugEnabled()) 
			{ integrationLogger.debug("ERPInExt:dateToMaximo");}

		if (isNull(sapDate) || Double.parseDouble(sapDate) == 0) {
			return getCurrentDate();
		}

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			return sdf.parse(sapDate);
		} catch (Exception e) {
			throw new MXApplicationException("iface", "sap_invalidDate");
		}
	}

	/**
	 * get CurrentDate
	 * 
	 * @return currentData
	 * @exception MXException
	 *                MAXIMO exception
	 * @exception RemoteException
	 *                Remote exception
	 */
	public static Date getCurrentDate() throws MXException, RemoteException {
		return new Date();
	}

	/**
	 * Check if the given value is null or empty.
	 * 
	 * @param -
	 *            s value to be checked
	 * @return true or false
	 */
	public static boolean isNull(String s) {
		if (s == null) {
			return true;
		}
		if (s.trim().equals("")) {
			return true;
		}
		return false;
	}

	/**
	 * We need to get the SAPCompanyCode based on the site and org
	 * 
	 * @param -
	 *            s value to be checked
	 * @return true or false
	 */
	public static String getSAPCompanyCode(String orgId, String siteId,
			UserInfo ui) {

		String companyCode = null;

		try {
			SiteSetRemote siteSet = (SiteSetRemote) MXServer.getMXServer()
					.getMboSet("SITE", ui);

			if (siteId != null && siteId.length() > 0) {
				siteSet.setWhere("SITEID = '" + siteId + "' and ORGID = '"
						+ orgId + "'");
				siteSet.reset();

				if (!siteSet.isEmpty()) {
					MboRemote siteRemote = siteSet.getMbo(0);
					companyCode = siteRemote.getString("CSC_CCN");
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getSAPCompanyCode "
						+ e);
			}

		}

		return companyCode;
	}

	/**
	 * 
	 * Maximo-Ariba integration Interface Table related utilities
	 * 
	 */

	public static String getTaxcode(String taxcode, UserInfo ui) {

		String description = "";

		try {
			TaxSetRemote taxSet = (TaxSetRemote) MXServer.getMXServer()
					.getMboSet("TAX", ui);

			if (taxcode != null && taxcode.length() > 0) {
				taxSet.setWhere("taxcode = '" + taxcode + "'");
				taxSet.reset();

				if (!taxSet.isEmpty()) {
					MboRemote taxRemote = taxSet.getMbo(0);
					description = taxRemote.getString("DESCRIPTION");
					if (isNull(description)) {
						description = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getTaxcode for "
						+ taxcode + " " + e);
			}
		}
		return description;
	}

	public static String getCompanyName(String company, UserInfo ui) {
		
		return getCompanyData(company, "NAME", ui);
		
	}

	
	public static String getTradeNetID(String company, UserInfo ui) {
	
		return getCompanyData(company, "CSC_TRADENETID", ui);
	}

	public static String getCompanyContact(String company, UserInfo ui)
	{
		return getCompanyData(company, "CONTACT", ui);
	}

	public static String getCompanyEmail(String company, UserInfo ui)
	{
		return getCompanyData(company, "CSC_EMAIL", ui);
	}
	
	public static String getCompanyData (String company, String dataName, UserInfo ui) 
	{
		String name = "";

		try {
			CompanySetRemote coSet = (CompanySetRemote) MXServer.getMXServer()
					.getMboSet("COMPANIES", ui);

			if (!isNull(company) && coSet != null) {
				coSet.setWhere("company = '" + company + "'");
				coSet.reset();

				if (!coSet.isEmpty()) {
					MboRemote coRemote = coSet.getMbo(0);
					name = coRemote.getString(dataName);
					if (isNull(name)) {
						name = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getVendorData for "
						+ company + " " + ":" + dataName + ":" + e);
			}
		}

		return name;
	}
	
	
	public static String getCompContactEmail(String company, String contact, UserInfo ui)
	{
		return getCompContactData(company, contact, "EMAIL", ui);
	}
	
	
	public static String getCompContactPhone(String company, String contact, UserInfo ui)
	{
		return getCompContactData(company, contact, "VOICEPHONE", ui);
	}
	
	
	public static String getCompContactData (String company, String contact, String dataName, UserInfo ui) 
	{
		String name = "";

		try {
			CompanySetRemote coSet = (CompanySetRemote) MXServer.getMXServer()
					.getMboSet("COMPCONTACT", ui);

			if (!isNull(company) && coSet != null) {
				coSet.setWhere("company = '" + company + "' and contact = '" + contact + "'");
				coSet.reset();

				if (!coSet.isEmpty()) {
					MboRemote coRemote = coSet.getMbo(0);
					name = coRemote.getString(dataName);
					if (isNull(name)) {
						name = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getCompContactData for "
						+ company + " " + ":" + dataName + ":" + e);
			}
		}

		return name;
	}
	
	
	public static String getCommodityGrpName(String commodityGrp, UserInfo ui) {
		String grpname = "";

		try {
			CommoditySetRemote coSet = (CommoditySetRemote) MXServer
					.getMXServer().getMboSet("COMMODITIES", ui);

			if (!isNull(commodityGrp) && coSet != null) {
				coSet.setWhere("commodity = '" + commodityGrp + "'");
				coSet.reset();

				if (!coSet.isEmpty()) {
					MboRemote coRemote = coSet.getMbo(0);
					grpname = coRemote.getString("DESCRIPTION");
					if (isNull(grpname)) {
						grpname = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger
						.info("Error in Utilities getCommodityGrpName for "
								+ commodityGrp + " " + e);
			}
		}
		return grpname;
	}

	public static String getCommodityName(String commodity, UserInfo ui) {
		String name = "";

		try {
			CommoditySetRemote coSet = (CommoditySetRemote) MXServer
					.getMXServer().getMboSet("COMMODITIES", ui);

			if (!isNull(commodity) && coSet != null) {
				coSet.setWhere("commodity = '" + commodity + "'");
				coSet.reset();

				if (!coSet.isEmpty()) {
					MboRemote coRemote = coSet.getMbo(0);
					name = coRemote.getString("DESCRIPTION");
					if (isNull(name)) {
						name = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger
						.info("Error in Utilities getCommodityName for "
								+ commodity + " " + e);
			}
		}
		return name;
	}

	public static String getItemString(String itemnum, UserInfo ui,
			String strType) {
		String name = "";

		try {
			ItemSetRemote itemSet = (ItemSetRemote) MXServer.getMXServer()
					.getMboSet("ITEM", ui);

			if (!isNull(itemnum) && itemSet != null) {
				itemSet.setWhere("itemnum = '" + itemnum + "'");
				itemSet.reset();

				if (!itemSet.isEmpty()) {
					MboRemote coRemote = itemSet.getMbo(0);
					name = coRemote.getString(strType);
					if (isNull(name)) {
						name = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getItemString for "
						+ itemnum + " and type " + strType + "  " + e);
			}
		}
		return name;
	}

	public static String getOrgName(String orgid, UserInfo ui) {
		String name = "";

		try {
			OrganizationSetRemote orgSet = (OrganizationSetRemote) MXServer
					.getMXServer().getMboSet("ORGANIZATION", ui);

			if (!isNull(orgid) && orgSet != null) {
				orgSet.setWhere("orgid = '" + orgid + "'");
				orgSet.reset();

				if (!orgSet.isEmpty()) {
					MboRemote coRemote = orgSet.getMbo(0);
					name = coRemote.getString("DESCRIPTION");
					if (isNull(name)) {
						name = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getOrgName for "
						+ orgid + " " + e);
			}
		}
		return name;
	}

	public static String getSiteName(String siteid, UserInfo ui) {
		
		return getSiteData(siteid, "DESCRIPTION", ui);

	}
	
	public static String getSiteIMO(String siteid, UserInfo ui)
	{
		return getSiteData(siteid, "CSC_IMONO", ui);
	}
	
	public static String getSiteData(String siteid, String dataName, UserInfo ui) {
		String name = "";

		try {
			SiteSetRemote siteSet = (SiteSetRemote) MXServer.getMXServer()
					.getMboSet("SITE", ui);

			if (!isNull(siteid) && siteSet != null) {
				siteSet.setWhere("siteid = '" + siteid + "'");
				siteSet.reset();

				if (!siteSet.isEmpty()) {
					MboRemote coRemote = siteSet.getMbo(0);
					name = coRemote.getString(dataName);
					if (isNull(name)) {
						name = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getSiteName for "
						+ siteid + " " + e);
			}
		}
		return name;
	}

	public static String getPersonName(String personid, UserInfo ui) {
		
		return getPersonData(personid, "DISPLAYNAME", ui);
	}

	public static String getPersonEmail(String personid, UserInfo ui) {
	
		return getPersonData(personid, "CSC_EMAIL", ui);
	}
	
	public static String getPersonData(String personID, String dataName, UserInfo ui) 
	{
		String result = "";

		try {
			PersonSetRemote personSet = (PersonSetRemote) MXServer
					.getMXServer().getMboSet("PERSON", ui);

			if (!isNull(personID) && personSet != null) {

				personSet.setWhere("personid = '" + personID + "'");
				personSet.reset();

				if (!personSet.isEmpty()) {
					MboRemote personRemote = personSet.getMbo(0);
					result = personRemote.getString(dataName);
					if (isNull(result)) {
						result = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getPersonData for "
						+ personID + ":" + dataName + " "+ e);
			}
		}
		return result;
	}
	
	
	public static String getPersonWorkPhone(String personid, UserInfo ui) {
		
		return getPhoneData(personid, "WORK", ui);
	}
	
	
	public static String getPhoneData(String personID, String phoneType, UserInfo ui) 
	{
		String result = "";

		try {
			PhoneSetRemote personSet = (PhoneSetRemote) MXServer
					.getMXServer().getMboSet("PHONE", ui);

			if (!isNull(personID) && personSet != null) {

				personSet.setWhere("personid = '" + personID + "' and type = '" + phoneType + "'");
				personSet.reset();

				if (!personSet.isEmpty()) {
					MboRemote personRemote = personSet.getMbo(0);
					result = personRemote.getString("PHONENUM");
					if (isNull(result)) {
						result = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getPersonData for "
						+ personID + ":" + phoneType + " "+ e);
			}
		}
		return result;
	}

	
	public static String getPersonWorkEmail (String personID, UserInfo ui)
	{
		return getEmailData(personID, "WORK", ui);
		
	}
	
	
	public static String getEmailData(String personID, String addrType, UserInfo ui) 
	{
		String result = "";

		try {
			EmailSetRemote personSet = (EmailSetRemote) MXServer
					.getMXServer().getMboSet("EMAIL", ui);

			if (!isNull(personID) && personSet != null) {

				personSet.setWhere("personid = '" + personID + "' and type = '" + addrType + "'");
				personSet.reset();

				if (!personSet.isEmpty()) {
					MboRemote personRemote = personSet.getMbo(0);
					result = personRemote.getString("EMAILADDRESS");
					if (isNull(result)) {
						result = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getEmailData for "
						+ personID + ":" + addrType + " "+ e);
			}
		}
		return result;
	}
	
	
	public static String getLabourPersonID (String labourCode, UserInfo ui)
	{
		return getLabourData(labourCode, "PERSONID", ui);
	}
	
	
	public static String getLabourData(String labourCode, String dataName, UserInfo ui) 
	{
		String result = "";

		try {
			LaborSetRemote personSet = (LaborSetRemote) MXServer
					.getMXServer().getMboSet("LABOR", ui);

			if (!isNull(labourCode) && personSet != null) {

				personSet.setWhere("laborcode = '" + labourCode + "'");
				personSet.reset();

				if (!personSet.isEmpty()) {
					MboRemote personRemote = personSet.getMbo(0);
					result = personRemote.getString(dataName);
					if (isNull(result)) {
						result = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getLabourData for "
						+ labourCode + ":" + dataName + " "+ e);
			}
		}
		return result;
	}


	public static String[] getAddress(String addrCode, UserInfo ui) {
		String[] addr = { "", "", "", "" };

		try {
			AddressSetRemote addrSet = (AddressSetRemote) MXServer
					.getMXServer().getMboSet("ADDRESS", ui);

			if (!isNull(addrCode) && addrSet != null) {
				addrSet.setWhere("addresscode = '" + addrCode + "'");
				addrSet.reset();

				if (!addrSet.isEmpty()) {
					MboRemote addrRemote = addrSet.getMbo(0);
					addr[0] = addrRemote.getString("ADDRESS1");
					addr[1] = addrRemote.getString("ADDRESS2");
					addr[2] = addrRemote.getString("ADDRESS3");
					addr[3] = addrRemote.getString("ADDRESS4");
					for (int i = 0; i<addrSet.count(); i++) {
						if (isNull(addr[i])) {
							addr[i] = "";
						}
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getAddress for "
						+ addrCode + " " + e);
			}
		}
		return addr;
	}

	public static String getMaximoUnitPrice(String siteID, String poNum, String poLineNum, UserInfo ui)
	{
		String result = "";

		try {
			POLineSetRemote polSet = (POLineSetRemote) MXServer
					.getMXServer().getMboSet("POLINE", ui);

			if (!isNull(poNum) && polSet != null) {

				polSet.setWhere("ponum = '" + poNum + "' and polinenum = '" + poLineNum  + "'");
				polSet.reset();

				if (!polSet.isEmpty()) {
					MboRemote polRemote = polSet.getMbo(0);
					result = polRemote.getString("UNITCOST");
					if (isNull(result)) {
						result = "";
					}
				}
			}
		} catch (Exception e) {
			if (integrationLogger.isInfoEnabled()) {
				integrationLogger.info("Error in Utilities getLabourData for "
						+ poNum + ":" + poLineNum + " "+ e);
			}
		}
		return result;
	}
	
	public static String getVendorfromTradeNetID(String tradeID, UserInfo ui) throws RemoteException, MXException
	{   
		// Setup the Environment
		if (integrationLogger.isDebugEnabled()) 
		    { integrationLogger.debug("--->> CSC_VendorTradeNEt: Start GetVendorfromTradeNetID for: " + tradeID);}
		
		CompanySetRemote compSet = (CompanySetRemote) MXServer.getMXServer().getMboSet("COMPANIES", ui);
		compSet.setWhere("csc_tradenetid = '" + tradeID + "'");
		compSet.reset();

		if (compSet.isEmpty())
		{
			// no records retreived so return the Default value
			compSet.cleanup();
			if (integrationLogger.isDebugEnabled()) 
	   		   { integrationLogger.error("--->>CSC_VendorTradeNEt: Vendor/Company Lookup Failed for: " + tradeID);}
			return "noneFound";
		}
 	    // get the requested row from COMMODITIES and return the CSC_SAPGLACCT
		try
		{
			MboRemote compMbo = compSet.getMbo(0);
            
   	    	String resultVal = compMbo.getString("COMPANY");
   	    	
   	    	if (integrationLogger.isDebugEnabled()) 
   	    	{   integrationLogger.debug("--->>CSC_VendorTradeNEt: Lookup Arguments: " + tradeID );
   	    	    integrationLogger.debug("--->>CSC_VendorTradeNEt: Lookup Result: " + resultVal); }
            
   	    	compSet.cleanup();
   	    	return resultVal;
		}
    	catch (MXException e)
    	{
    		//   catch all exceptions and return the vendor number passed as there is
    		//   no CrossRef 
    		integrationLogger.error("--->>CSC_VendorTradeNEt: Lookup Exception for: " + tradeID);
    		compSet.cleanup();
    		return "none";
    	}
	} 
	
	
	public static int getQuoteLineID(String rfqNum, String rfqLineNo, String vendorNum, UserInfo ui) throws RemoteException, MXException
	{   
		// Setup the Environment
		if (integrationLogger.isDebugEnabled()) 
		    { integrationLogger.debug("--->> GetQuoteLineID: Start for: " + rfqNum 
		    		+ ":" + rfqLineNo + ":" + vendorNum);}
		
		QuotationLineSetRemote qSet = (QuotationLineSetRemote) MXServer.getMXServer().getMboSet("QUOTATIONLINE", ui);
		qSet.setWhere("rfqnum = '" + rfqNum + "' and rfqlinenum = '" + rfqLineNo + "' and vendor = '" + vendorNum + "'");
		qSet.reset();

		if (qSet.isEmpty())
		{
			// no records retreived so return the Default value
			qSet.cleanup();
			if (integrationLogger.isDebugEnabled()) 
	   		   { integrationLogger.error("--->>Get QUOTATIONLINEID failed: ");}
			return 0;
		}
 	    // get the requested row from QUOTATIONLINE and reutnr the ID field
		try
		{
			MboRemote qLineMbo = qSet.getMbo(0);
            
   	    	int resultVal = qLineMbo.getInt("QUOTATIONLINEID");
   	    	
   	    	if (integrationLogger.isDebugEnabled()) 
   	    	{  integrationLogger.debug("--->>Get QUOTATIONLINEID: Lookup Result: " + resultVal); }
            
   	    	qSet.cleanup();
   	    	return resultVal;
		}
    	catch (MXException e)
    	{
    		//   catch all exceptions and return the vendor number passed as there is
    		//   no CrossRef 
    		integrationLogger.error("--->>Get QUOTATIONLINEID exception: " + e.toString());
    		qSet.cleanup();
    		return 0;
    	}
	} 
	
	
	public static void createQuoteLines(String siteID, String rfqNum, String vendorNum) throws RemoteException, MXException
	   {
	  		// Setup the Environment
		    if (integrationLogger.isDebugEnabled()) 
		       {integrationLogger.debug("--->>createQuoteLines: Start for: " + siteID + ":" + rfqNum + ":" + vendorNum);}
			
		    // get the server object specifically as it doesn't work in the getMboSetRemote...
		    MXServer mxServer = MXServer.getMXServer();			
		    UserInfo userInfo = mxServer.getUserInfo("maxadmin"); 
		    
		    //  don not create any lines if QUoteLInes already exist for this vendor
		    MboSetRemote qSet = mxServer.getMboSet("QUOTATIONLINE", userInfo);
		    qSet.setWhere("vendor = '" + vendorNum + "' and rfqnum = '" + rfqNum + "'");
		    qSet.reset();
		    
		    int qCount = qSet.count();
		    qSet.cleanup();
		    
		    if (qCount == 0)
		    {
			    // quotelines DO NOT exist for this Vendor on this RFQ, so Create
				// them by looping thru each RFQLINE
				// for the current Vendor and call the RFQLINE process to
				// copyRFQLines to QuotationLInes
				RFQLineSet rfqLineSet = (RFQLineSet) mxServer.getMboSet("RFQLINE", userInfo);
				rfqLineSet.setWhere("siteid='" + siteID + "' and rfqnum='" + rfqNum	+ "'");
				rfqLineSet.reset();
	
				if (integrationLogger.isDebugEnabled()) 
				    {integrationLogger.debug(" ====>>buildQUoteLIne:RFQLineCount to process:"	+ rfqLineSet.count());}
	
				// loop thru the lines retreived and create a corresponding
				// quoteline for
				// the vendornum passed
				for (int i = 0; i < rfqLineSet.count(); i++) 
				{
					// Process the current RFQLIne just retreived
					RFQLineRemote rfqLineMbo = (RFQLineRemote) rfqLineSet.getMbo(i);
					if (integrationLogger.isDebugEnabled()) 
						{integrationLogger.debug("===>createQuoteLInes: Just retreived RFQLINE: "
									+ rfqLineMbo.getString("RFQNUM") + ":" + rfqLineMbo.getString("RFQLINENUM"));}
	
					rfqLineMbo.copyRFQLinesToQuotationLines(vendorNum);
					if (integrationLogger.isDebugEnabled()) 
					{
					     integrationLogger.debug(" ====>>createQuoteLInes:after createQuoteLInes from UserExit: "
									+ siteID + ":" + rfqNum + ":" + vendorNum);
					}

				}
	
				// save the RFQ Line Set that contains the QuoteLInes just created
				if (integrationLogger.isDebugEnabled()) 
				    {integrationLogger.debug("====>>buildQUoteLIne:issue commit and cleanup for this line");}
				
				rfqLineSet.save();
				rfqLineSet.cleanup();
		    }
		    else
		    {
		    	// quote lines already exist, so throw skip_transacion exception
		    	if (integrationLogger.isDebugEnabled()) 
			        {integrationLogger.debug("====>>buildQUoteLIne:QUote LInes exist for this vendor/rfqnum: " 
			    		 + vendorNum + ":" + rfqNum + ":" + " line count: " + qCount);}
			        
		    }

			integrationLogger.info(" ====>>>>> buildQUoteLIne:End of Processing  <<<<<================");
		
	   }
	
	public static void submitBirtReport(String siteID, String rfqNum, String vendorNum, String reportName) throws RemoteException, MXException
	   {
	  		// Setup the Environment
			integrationLogger.debug("--->>submitBirtReport: Start for: " + siteID + ":" + rfqNum + ":" + vendorNum);
			
	   }
	
	public static void changePOStatus(String poNum, String siteID, String newStatus, String chgMemo) throws RemoteException, MXException
	   
	   {
		    //   change the Status of the PO to the new status passed. Throw an exception if status
		    //   changes is invalid
		    if (integrationLogger.isDebugEnabled()) {
			    integrationLogger.debug("--->>CSC Util: changePO status for: " + siteID + ":" + poNum + ":" + newStatus);
		    }
			
			// get the session information...
		    // get the server object specifically as it doesn't work in the getMboSetRemote...
		    MXServer mxServer = MXServer.getMXServer(); 
		    UserInfo userInfo = mxServer.getUserInfo("maxadmin"); 

			POSetRemote poSet = (POSetRemote) mxServer.getMboSet("PO", userInfo);
	    	poSet.setWhere("siteid = '" + siteID + "' and ponum = '" + poNum + "'");
	    	poSet.reset();
	    	
	    	if (poSet.count() > 0)
	    	{
	    		//  get the Mbo for the PO just retreived and change the status.
	    		PO myPO = (PO)poSet.getMbo(0);
	    		String currentStatus = myPO.getString("STATUS");
	    		if (integrationLogger.isDebugEnabled()) {
	    			integrationLogger.debug("---->>ChangePOStatus: from: " + currentStatus + " to: " + newStatus);
	    		}
	    		
	    		//   change the status
	    		Date now = new Date(); 
	    		if (! currentStatus.equalsIgnoreCase(newStatus))
	    		{
	    		     myPO.changeStatus(newStatus, now, chgMemo);
	    		     poSet.save();
	    		}
	    		poSet.cleanup();
	    		
	    	}
	    	
	    	if (integrationLogger.isDebugEnabled()) {
	    		integrationLogger.debug("CSC Util: Complete PO Status Change utility...");
	    	}
		   
	   }
	
	public static void changeRFQStatus(String rfqNum, String siteID, String newStatus, String chgMemo) throws RemoteException, MXException
	   
	   {
		    //   change the Status of the RFQ to the new status passed. Throw an exception if status
		    //   changes is invalid. 
		    if (integrationLogger.isDebugEnabled()) {
			    integrationLogger.debug("--->>CSC Util: changeRFQ status for: " + siteID + ":" + rfqNum + ":" + newStatus);
		    }
			
			// get the session information...
		    // get the server object specifically as it doesn't work in the getMboSetRemote...
		    MXServer mxServer = MXServer.getMXServer(); 
		    UserInfo userInfo = mxServer.getUserInfo("maxadmin"); 

			RFQSetRemote rfqSet = (RFQSetRemote) mxServer.getMboSet("RFQ", userInfo);
	    	rfqSet.setWhere("siteid = '" + siteID + "' and rfqnum = '" + rfqNum + "'");
	    	rfqSet.reset();
	    	
	    	if (rfqSet.count() > 0)
	    	{
	    		//  get the Mbo for the PO just retreived and change the status.
	    		RFQ myRFQ = (RFQ)rfqSet.getMbo(0);
	    		String currentStatus = myRFQ.getString("STATUS");
	    		if (integrationLogger.isDebugEnabled()) {
	    			integrationLogger.debug("---->>ChangeRFQStatus: from: " + currentStatus + " to: " + newStatus);
	    		}
	    		
	    		//   change the status
	    		Date now = new Date(); 
	    		if (! currentStatus.equalsIgnoreCase(newStatus))
	    		{
	    		   myRFQ.changeStatus(newStatus, now, chgMemo);
	    		   rfqSet.save();
	    		}
	    		//  cleanup the set just used
	    		rfqSet.cleanup();
	    		
	    	}
	    	
		    integrationLogger.debug("CSC Util: Complete PO Status Change utility...");
		   
	   }
	
	//   get the RFQ reference for the PO and POLINENUM passed
	// 
	public static String[] getRFQReference(String poNum, String poLineNum, UserInfo ui)
	{
		String[] result = new String[2];

	    if (integrationLogger.isDebugEnabled()) {
		    integrationLogger.debug("--->>CSC Util: getRFQRef for: " + poNum + ":" + poLineNum);
	    }
	    
		try {
			RFQLineSetRemote rfqSet = (RFQLineSetRemote) MXServer.getMXServer().getMboSet("RFQLINE", ui);

			if (!isNull(poNum) && rfqSet != null) {

				rfqSet.setWhere("ponum = '" + poNum + "' and polinenum = '" + poLineNum  + "'");
				rfqSet.reset();

				if (!rfqSet.isEmpty()) {
					//  there may be more than 1 row retreived, arbitrarily use
					//  the first row returned
					MboRemote rfqMbo = rfqSet.getMbo(0);
					result[0] = rfqMbo.getString("RFQNUM");
					result[1] = rfqMbo.getString("RFQLINENUM").toString();
				}
				rfqSet.close();
				rfqSet.cleanup();
				return result;
			}
		} catch (Exception e) {
				integrationLogger.error("Error in ShipServUtilities getRFQRef for "
						+ poNum + ":" + poLineNum + " "+ e);
				result[0] = null;
				result[1] = null;
				return result;
		}
		return result;
	}
	
 	
    public static String getSitefromIMONum(String IMONum) throws RemoteException, MXException
    {   
    		// Setup the Environment
    	if (integrationLogger.isDebugEnabled()) {
    		   integrationLogger.debug("--->>CSC_SiteIMO: Start GetSitefromIMONum for: " + IMONum);}
    		
            //		 get the session information...
    	    // get the server object specifically as it doesn't work in the getMboSetRemote...
    	    MXServer mxServer = MXServer.getMXServer(); 
    	    UserInfo userInfo = mxServer.getUserInfo("maxadmin"); 
    	    
            MboSet xrefSet = (MboSet) mxServer.getMboSet("SITE",userInfo);
    		SqlFormat sqfXref = new SqlFormat(userInfo, "csc_imono = :1");
    		sqfXref.setObject(1, "SITE", "CSC_IMONO", IMONum);
    		xrefSet.setWhere(sqfXref.format());
    		xrefSet.reset();
    		
    		if (xrefSet.isEmpty())
    		{
    			// no records retreived so return the Default value
    			xrefSet.cleanup();
    			if (integrationLogger.isDebugEnabled()) {
    	   		    integrationLogger.error("--->>CSC_SiteIMO: SiteID lookup not found for: " + IMONum);}
    			return "noneFound";
    		}
     	    // get the requested row from COMMODITIES and return the CSC_SAPGLACCT
    		try
    		{
    			MboRemote xrefMbo = xrefSet.getMbo(0);
                
       	    	String resultVal = xrefMbo.getString("SITEID");
       	    	
       	    	if (integrationLogger.isDebugEnabled()) {
       	    	     integrationLogger.debug("--->>CSC_SiteIMONum: Lookup Arguments: " + IMONum );
       	    	     integrationLogger.debug("--->>CSC_SiteIMONum: Lookup Result: " + resultVal);}
                
       	    	xrefSet.cleanup();
       	    	return resultVal;
    		}
        	catch (MXException e)
        	{
        		//   catch all exceptions and return the vendor number passed as there is
        		//   no CrossRef 
        		integrationLogger.error("--->>CSC_SiteIMONum: Lookup Exception for: " + IMONum);
        		xrefSet.cleanup();
        		return "none";
        	}
    }
	

}     //  end of package

